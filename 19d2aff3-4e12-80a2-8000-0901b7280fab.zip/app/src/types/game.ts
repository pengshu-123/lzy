export type Target = {
  id: number;
  x: number;
  y: number;
  size: number;
  createdAt: number;
  hit?: boolean;
};

export type GameStats = {
  score: number;
  hits: number;
  misses: number;
  totalShots: number;
  accuracy: number;
  avgReactionTime: number;
  reactionTimes: number[];
};

export type GameConfig = {
  targetSize: number;
  targetDuration: number;
  spawnInterval: number;
  totalTime: number;
};

export type GameState = 'menu' | 'playing' | 'paused' | 'finished';

export type Difficulty = 'easy' | 'medium' | 'hard' | 'extreme';

export const DIFFICULTY_CONFIG: Record<Difficulty, GameConfig> = {
  easy: {
    targetSize: 80,
    targetDuration: 3000,
    spawnInterval: 1000,
    totalTime: 60,
  },
  medium: {
    targetSize: 60,
    targetDuration: 2000,
    spawnInterval: 800,
    totalTime: 60,
  },
  hard: {
    targetSize: 40,
    targetDuration: 1500,
    spawnInterval: 600,
    totalTime: 60,
  },
  extreme: {
    targetSize: 25,
    targetDuration: 1000,
    spawnInterval: 400,
    totalTime: 60,
  },
};
