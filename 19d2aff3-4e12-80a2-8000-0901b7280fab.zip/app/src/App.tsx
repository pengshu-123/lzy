import { useGame } from '@/hooks/useGame';
import { GameArea } from '@/components/GameArea';
import { HUD } from '@/components/HUD';
import { Menu } from '@/components/Menu';
import { GameOver } from '@/components/GameOver';
import { PauseMenu } from '@/components/PauseMenu';
import { DIFFICULTY_CONFIG } from '@/types/game';
import { Pause } from 'lucide-react';
import { Button } from '@/components/ui/button';

function App() {
  const {
    gameState,
    difficulty,
    setDifficulty,
    targets,
    stats,
    timeLeft,
    combo,
    maxCombo,
    gameAreaRef,
    startGame,
    pauseGame,
    handleTargetHit,
    handleMiss,
    resetGame,
  } = useGame();

  const config = DIFFICULTY_CONFIG[difficulty];

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-hidden">
      {/* Game Container */}
      <div className="relative w-full h-screen">
        {/* Background Effects */}
        <BackgroundEffects />

        {/* Main Content */}
        <div className="relative z-10 w-full h-full">
          {gameState === 'menu' && (
            <Menu
              onStart={startGame}
              difficulty={difficulty}
              onDifficultyChange={setDifficulty}
            />
          )}

          {(gameState === 'playing' || gameState === 'paused') && (
            <>
              {/* Game Area */}
              <div className="absolute inset-0 pt-32">
                <GameArea
                  ref={gameAreaRef}
                  targets={targets}
                  config={config}
                  onTargetHit={handleTargetHit}
                  onMiss={handleMiss}
                  isPlaying={gameState === 'playing'}
                />
              </div>

              {/* HUD */}
              <HUD
                stats={stats}
                timeLeft={timeLeft}
                combo={combo}
                maxCombo={maxCombo}
              />

              {/* Pause Button */}
              <div className="absolute top-4 right-4 z-30">
                <Button
                  onClick={pauseGame}
                  variant="outline"
                  size="icon"
                  className="w-12 h-12 border-cyan-500/30 bg-slate-900/80 hover:bg-slate-800"
                >
                  <Pause className="w-5 h-5 text-cyan-400" />
                </Button>
              </div>

              {/* Pause Menu */}
              {gameState === 'paused' && (
                <PauseMenu
                  onResume={pauseGame}
                  onRestart={startGame}
                  onMenu={resetGame}
                />
              )}
            </>
          )}

          {gameState === 'finished' && (
            <GameOver
              stats={stats}
              maxCombo={maxCombo}
              onRestart={startGame}
              onMenu={resetGame}
            />
          )}
        </div>
      </div>
    </div>
  );
}

// Background effects component
function BackgroundEffects() {
  return (
    <>
      {/* Animated gradient orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div 
          className="absolute w-[600px] h-[600px] rounded-full opacity-20"
          style={{
            background: 'radial-gradient(circle, rgba(6,182,212,0.4) 0%, transparent 70%)',
            top: '-200px',
            left: '-200px',
            animation: 'float 20s ease-in-out infinite',
          }}
        />
        <div 
          className="absolute w-[500px] h-[500px] rounded-full opacity-15"
          style={{
            background: 'radial-gradient(circle, rgba(147,51,234,0.4) 0%, transparent 70%)',
            bottom: '-150px',
            right: '-150px',
            animation: 'float 25s ease-in-out infinite reverse',
          }}
        />
        <div 
          className="absolute w-[400px] h-[400px] rounded-full opacity-10"
          style={{
            background: 'radial-gradient(circle, rgba(59,130,246,0.4) 0%, transparent 70%)',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            animation: 'pulse 15s ease-in-out infinite',
          }}
        />
      </div>

      {/* Scanlines */}
      <div 
        className="absolute inset-0 pointer-events-none opacity-5"
        style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.3) 2px, rgba(0,0,0,0.3) 4px)',
        }}
      />

      {/* Vignette */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 40%, rgba(2,6,23,0.8) 100%)',
        }}
      />

      {/* CSS Animations */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(30px, -30px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 0.1; transform: translate(-50%, -50%) scale(1); }
          50% { opacity: 0.2; transform: translate(-50%, -50%) scale(1.2); }
        }
      `}</style>
    </>
  );
}

export default App;
