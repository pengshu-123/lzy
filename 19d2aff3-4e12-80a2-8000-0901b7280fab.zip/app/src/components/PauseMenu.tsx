import { Play, Home, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface PauseMenuProps {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
}

export function PauseMenu({ onResume, onRestart, onMenu }: PauseMenuProps) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-cyan-500/30 rounded-2xl p-8 max-w-sm w-full mx-4 shadow-[0_0_50px_rgba(6,182,212,0.2)]">
        <h2 className="text-3xl font-bold text-white text-center mb-8">PAUSED</h2>
        
        <div className="space-y-3">
          <Button
            onClick={onResume}
            className="w-full py-6 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-lg"
          >
            <Play className="w-5 h-5 mr-2" />
            RESUME
          </Button>
          
          <Button
            onClick={onRestart}
            variant="outline"
            className="w-full py-6 border-slate-600 text-slate-300 hover:bg-slate-800 hover:text-white"
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            RESTART
          </Button>
          
          <Button
            onClick={onMenu}
            variant="outline"
            className="w-full py-6 border-slate-600 text-slate-300 hover:bg-slate-800 hover:text-white"
          >
            <Home className="w-5 h-5 mr-2" />
            MAIN MENU
          </Button>
        </div>
      </div>
    </div>
  );
}
