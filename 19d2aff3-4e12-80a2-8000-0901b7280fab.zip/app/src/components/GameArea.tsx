import { forwardRef } from 'react';
import { TargetComponent } from './Target';
import type { Target, GameConfig } from '@/types/game';
import { Crosshair } from 'lucide-react';

interface GameAreaProps {
  targets: Target[];
  config: GameConfig;
  onTargetHit: (id: number, createdAt: number) => void;
  onMiss: () => void;
  isPlaying: boolean;
}

export const GameArea = forwardRef<HTMLDivElement, GameAreaProps>(
  ({ targets, config, onTargetHit, onMiss, isPlaying }, ref) => {
    const handleAreaClick = () => {
      if (isPlaying) {
        onMiss();
      }
    };

    return (
      <div
        ref={ref}
        className="relative w-full h-full bg-slate-950 overflow-hidden cursor-crosshair"
        onClick={handleAreaClick}
      >
        {/* Grid background */}
        <div 
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: `
              linear-gradient(rgba(6, 182, 212, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(6, 182, 212, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: '50px 50px',
          }}
        />
        
        {/* Radial gradient overlay */}
        <div 
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at center, transparent 0%, rgba(2, 6, 23, 0.8) 100%)',
          }}
        />

        {/* Corner decorations */}
        <div className="absolute top-4 left-4 w-16 h-16 border-l-2 border-t-2 border-cyan-500/50" />
        <div className="absolute top-4 right-4 w-16 h-16 border-r-2 border-t-2 border-cyan-500/50" />
        <div className="absolute bottom-4 left-4 w-16 h-16 border-l-2 border-b-2 border-cyan-500/50" />
        <div className="absolute bottom-4 right-4 w-16 h-16 border-r-2 border-b-2 border-cyan-500/50" />

        {/* Center crosshair when not playing */}
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <Crosshair className="w-16 h-16 text-cyan-500/30" />
          </div>
        )}

        {/* Targets */}
        {targets.map((target) => (
          <TargetComponent
            key={target.id}
            target={target}
            onHit={onTargetHit}
            duration={config.targetDuration}
          />
        ))}

        {/* Hit effect particles */}
        <HitEffects />
      </div>
    );
  }
);

GameArea.displayName = 'GameArea';

// Simple hit effects component
function HitEffects() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {[...Array(5)].map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 bg-cyan-400 rounded-full animate-pulse"
          style={{
            left: `${20 + i * 15}%`,
            top: `${30 + (i % 3) * 20}%`,
            animationDelay: `${i * 0.2}s`,
            opacity: 0.3,
          }}
        />
      ))}
    </div>
  );
}
