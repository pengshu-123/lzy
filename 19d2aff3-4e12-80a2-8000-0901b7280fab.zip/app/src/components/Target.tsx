import { useEffect, useState } from 'react';
import type { Target as TargetType } from '@/types/game';

interface TargetProps {
  target: TargetType;
  onHit: (id: number, createdAt: number) => void;
  duration: number;
}

export function TargetComponent({ target, onHit, duration }: TargetProps) {
  const [scale, setScale] = useState(0);
  const [opacity, setOpacity] = useState(1);

  useEffect(() => {
    // Spawn animation
    requestAnimationFrame(() => {
      setScale(1);
    });

    // Shrink animation
    const shrinkTimeout = setTimeout(() => {
      setScale(0.7);
    }, duration * 0.5);

    // Fade out before disappearing
    const fadeTimeout = setTimeout(() => {
      setOpacity(0);
    }, duration * 0.8);

    return () => {
      clearTimeout(shrinkTimeout);
      clearTimeout(fadeTimeout);
    };
  }, [duration]);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onHit(target.id, target.createdAt);
  };

  return (
    <div
      className="absolute cursor-pointer select-none"
      style={{
        left: target.x - target.size / 2,
        top: target.y - target.size / 2,
        width: target.size,
        height: target.size,
        transform: `scale(${scale})`,
        opacity,
        transition: `transform ${duration * 0.001}s ease-out, opacity ${duration * 0.2 * 0.001}s ease-out`,
      }}
      onClick={handleClick}
    >
      {/* Outer ring */}
      <div 
        className="absolute inset-0 rounded-full border-2 border-cyan-400/50 animate-ping"
        style={{ animationDuration: `${duration * 0.001}s` }}
      />
      
      {/* Main target */}
      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 shadow-[0_0_30px_rgba(6,182,212,0.6)]">
        {/* Inner rings */}
        <div className="absolute inset-[15%] rounded-full border-2 border-white/60" />
        <div className="absolute inset-[30%] rounded-full bg-white/20" />
        <div className="absolute inset-[45%] rounded-full bg-white" />
        
        {/* Crosshair */}
        <div className="absolute top-1/2 left-0 right-0 h-[2px] bg-white/40 -translate-y-1/2" />
        <div className="absolute left-1/2 top-0 bottom-0 w-[2px] bg-white/40 -translate-x-1/2" />
      </div>
    </div>
  );
}
