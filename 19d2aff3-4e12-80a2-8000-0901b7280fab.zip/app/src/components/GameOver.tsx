import type { GameStats } from '@/types/game';
import { Trophy, Crosshair, Zap, Clock, RotateCcw, Home, TrendingUp, Flame, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface GameOverProps {
  stats: GameStats;
  maxCombo: number;
  onRestart: () => void;
  onMenu: () => void;
}

export function GameOver({ stats, maxCombo, onRestart, onMenu }: GameOverProps) {
  const formatReactionTime = (ms: number) => {
    if (!ms || isNaN(ms)) return '---';
    return `${Math.round(ms)}ms`;
  };

  // Calculate grade
  const getGrade = () => {
    const accuracy = stats.accuracy;
    const avgReaction = stats.avgReactionTime;
    
    if (accuracy >= 90 && avgReaction < 300) return { grade: 'S', color: 'text-yellow-400', glow: 'shadow-yellow-400/50' };
    if (accuracy >= 80 && avgReaction < 400) return { grade: 'A', color: 'text-green-400', glow: 'shadow-green-400/50' };
    if (accuracy >= 70 && avgReaction < 500) return { grade: 'B', color: 'text-blue-400', glow: 'shadow-blue-400/50' };
    if (accuracy >= 60) return { grade: 'C', color: 'text-orange-400', glow: 'shadow-orange-400/50' };
    return { grade: 'D', color: 'text-red-400', glow: 'shadow-red-400/50' };
  };

  const gradeInfo = getGrade();

  return (
    <div className="flex flex-col items-center justify-center h-full gap-6 p-8">
      {/* Title */}
      <div className="text-center">
        <h2 className="text-4xl font-bold text-white mb-2">TRAINING COMPLETE</h2>
        <p className="text-slate-400">Here are your results</p>
      </div>

      {/* Grade */}
      <div className={`relative w-32 h-32 flex items-center justify-center`}>
        <div className={`absolute inset-0 rounded-full bg-gradient-to-br from-cyan-500/20 to-purple-600/20 animate-pulse`} />
        <div className={`text-7xl font-bold ${gradeInfo.color} drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]`}>
          {gradeInfo.grade}
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-3xl">
        <StatBox
          icon={<Trophy className="w-6 h-6 text-yellow-400" />}
          label="FINAL SCORE"
          value={stats.score.toLocaleString()}
          highlight
        />
        <StatBox
          icon={<Flame className="w-6 h-6 text-orange-400" />}
          label="MAX COMBO"
          value={`${maxCombo}x`}
        />
        <StatBox
          icon={<Crosshair className="w-6 h-6 text-green-400" />}
          label="ACCURACY"
          value={`${stats.accuracy.toFixed(1)}%`}
        />
        <StatBox
          icon={<Zap className="w-6 h-6 text-cyan-400" />}
          label="AVG REACTION"
          value={formatReactionTime(stats.avgReactionTime)}
        />
      </div>

      {/* Detailed Stats */}
      <div className="w-full max-w-2xl bg-slate-900/80 border border-slate-700 rounded-xl p-6">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-cyan-400" />
          <span className="text-sm text-cyan-400/70 font-mono tracking-wider">DETAILED STATISTICS</span>
        </div>
        <div className="grid grid-cols-3 gap-6">
          <div className="text-center">
            <div className="text-3xl font-bold text-white font-mono">{stats.hits}</div>
            <div className="text-xs text-slate-500 mt-1">TARGETS HIT</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white font-mono">{stats.misses}</div>
            <div className="text-xs text-slate-500 mt-1">TARGETS MISSED</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white font-mono">{stats.totalShots}</div>
            <div className="text-xs text-slate-500 mt-1">TOTAL SHOTS</div>
          </div>
        </div>
      </div>

      {/* Performance Tips */}
      {stats.accuracy < 70 && (
        <div className="flex items-center gap-3 p-4 bg-orange-500/10 border border-orange-500/30 rounded-lg max-w-xl">
          <Award className="w-6 h-6 text-orange-400 flex-shrink-0" />
          <div className="text-sm text-orange-200">
            <strong>Tip:</strong> Focus on accuracy over speed. Take your time to aim before shooting.
          </div>
        </div>
      )}

      {stats.avgReactionTime > 500 && (
        <div className="flex items-center gap-3 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg max-w-xl">
          <Clock className="w-6 h-6 text-blue-400 flex-shrink-0" />
          <div className="text-sm text-blue-200">
            <strong>Tip:</strong> Try to react faster when targets appear. Anticipate their spawn locations.
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex items-center gap-4">
        <Button
          onClick={onMenu}
          variant="outline"
          className="px-6 py-5 border-slate-600 text-slate-300 hover:bg-slate-800 hover:text-white"
        >
          <Home className="w-5 h-5 mr-2" />
          Main Menu
        </Button>
        <Button
          onClick={onRestart}
          className="px-8 py-5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold"
        >
          <RotateCcw className="w-5 h-5 mr-2" />
          Play Again
        </Button>
      </div>
    </div>
  );
}

interface StatBoxProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  highlight?: boolean;
}

function StatBox({ icon, label, value, highlight }: StatBoxProps) {
  return (
    <div className={`p-4 rounded-xl border text-center ${
      highlight 
        ? 'bg-gradient-to-br from-cyan-500/10 to-blue-600/10 border-cyan-500/30' 
        : 'bg-slate-900/80 border-slate-700'
    }`}>
      <div className="flex justify-center mb-2">{icon}</div>
      <div className={`text-2xl font-bold font-mono ${highlight ? 'text-cyan-400' : 'text-white'}`}>
        {value}
      </div>
      <div className="text-xs text-slate-500 mt-1">{label}</div>
    </div>
  );
}
