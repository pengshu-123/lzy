import type { GameStats } from '@/types/game';
import { Target, Crosshair, Zap, Clock, TrendingUp, Flame } from 'lucide-react';

interface HUDProps {
  stats: GameStats;
  timeLeft: number;
  combo: number;
  maxCombo: number;
}

export function HUD({ stats, timeLeft, combo, maxCombo }: HUDProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatReactionTime = (ms: number) => {
    if (!ms || isNaN(ms)) return '---';
    return `${Math.round(ms)}ms`;
  };

  return (
    <div className="absolute top-0 left-0 right-0 z-20 p-4">
      {/* Main stats bar */}
      <div className="flex items-center justify-between gap-4">
        {/* Score */}
        <StatCard
          icon={<Target className="w-5 h-5 text-cyan-400" />}
          label="SCORE"
          value={stats.score.toLocaleString()}
          className="min-w-[140px]"
        />

        {/* Time */}
        <div className="flex-1 max-w-[200px]">
          <div className="bg-slate-900/90 border border-cyan-500/30 rounded-lg p-3 backdrop-blur-sm">
            <div className="flex items-center justify-center gap-2 mb-1">
              <Clock className="w-5 h-5 text-cyan-400" />
              <span className="text-xs text-cyan-400/70 font-mono tracking-wider">TIME</span>
            </div>
            <div className={`text-center font-mono text-3xl font-bold ${
              timeLeft <= 10 ? 'text-red-500 animate-pulse' : 'text-white'
            }`}>
              {formatTime(timeLeft)}
            </div>
          </div>
        </div>

        {/* Combo */}
        <div className="min-w-[140px]">
          <div className={`bg-slate-900/90 border rounded-lg p-3 backdrop-blur-sm transition-all ${
            combo > 5 ? 'border-orange-500/50 shadow-[0_0_20px_rgba(249,115,22,0.3)]' : 'border-cyan-500/30'
          }`}>
            <div className="flex items-center justify-center gap-2 mb-1">
              <Flame className={`w-5 h-5 ${combo > 5 ? 'text-orange-400' : 'text-cyan-400'}`} />
              <span className={`text-xs font-mono tracking-wider ${combo > 5 ? 'text-orange-400/70' : 'text-cyan-400/70'}`}>
                COMBO
              </span>
            </div>
            <div className={`text-center font-mono text-3xl font-bold ${
              combo > 5 ? 'text-orange-400' : 'text-white'
            }`}>
              {combo}x
            </div>
            {maxCombo > 0 && (
              <div className="text-center text-xs text-slate-500 mt-1">
                MAX: {maxCombo}x
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Secondary stats */}
      <div className="flex items-center justify-center gap-3 mt-3">
        <MiniStat
          icon={<Crosshair className="w-4 h-4" />}
          label="ACCURACY"
          value={`${stats.accuracy.toFixed(1)}%`}
        />
        <MiniStat
          icon={<Zap className="w-4 h-4" />}
          label="REACTION"
          value={formatReactionTime(stats.avgReactionTime)}
        />
        <MiniStat
          icon={<TrendingUp className="w-4 h-4" />}
          label="HITS"
          value={stats.hits.toString()}
        />
        <MiniStat
          icon={<Target className="w-4 h-4" />}
          label="MISSES"
          value={stats.misses.toString()}
        />
      </div>
    </div>
  );
}

interface StatCardProps {
  icon: React.ReactNode;
  label: string;
  value: string;
  className?: string;
}

function StatCard({ icon, label, value, className = '' }: StatCardProps) {
  return (
    <div className={`bg-slate-900/90 border border-cyan-500/30 rounded-lg p-3 backdrop-blur-sm ${className}`}>
      <div className="flex items-center gap-2 mb-1">
        {icon}
        <span className="text-xs text-cyan-400/70 font-mono tracking-wider">{label}</span>
      </div>
      <div className="text-2xl font-bold text-white font-mono">
        {value}
      </div>
    </div>
  );
}

interface MiniStatProps {
  icon: React.ReactNode;
  label: string;
  value: string;
}

function MiniStat({ icon, label, value }: MiniStatProps) {
  return (
    <div className="flex items-center gap-2 bg-slate-900/80 border border-cyan-500/20 rounded-md px-3 py-1.5 backdrop-blur-sm">
      <div className="text-cyan-400">{icon}</div>
      <div className="flex items-center gap-2">
        <span className="text-xs text-slate-400">{label}</span>
        <span className="text-sm font-mono font-semibold text-white">{value}</span>
      </div>
    </div>
  );
}
