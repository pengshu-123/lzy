import { useState } from 'react';
import type { Difficulty } from '@/types/game';
import { DIFFICULTY_CONFIG } from '@/types/game';
import { Target, Play, Settings, Trophy, Info, ChevronRight, Gamepad2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface MenuProps {
  onStart: () => void;
  difficulty: Difficulty;
  onDifficultyChange: (diff: Difficulty) => void;
}

export function Menu({ onStart, difficulty, onDifficultyChange }: MenuProps) {
  const [showInstructions, setShowInstructions] = useState(false);

  const difficulties: { value: Difficulty; label: string; desc: string; color: string }[] = [
    { value: 'easy', label: 'EASY', desc: 'Large targets, slow spawn', color: 'text-green-400' },
    { value: 'medium', label: 'MEDIUM', desc: 'Medium targets, normal speed', color: 'text-yellow-400' },
    { value: 'hard', label: 'HARD', desc: 'Small targets, fast spawn', color: 'text-orange-400' },
    { value: 'extreme', label: 'EXTREME', desc: 'Tiny targets, very fast', color: 'text-red-400' },
  ];

  const config = DIFFICULTY_CONFIG[difficulty];

  return (
    <div className="flex flex-col items-center justify-center h-full gap-8 p-8">
      {/* Logo */}
      <div className="text-center">
        <div className="flex items-center justify-center gap-4 mb-4">
          <div className="relative">
            <Target className="w-16 h-16 text-cyan-400" />
            <div className="absolute inset-0 animate-ping">
              <Target className="w-16 h-16 text-cyan-400/50" />
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            AIM LAB
          </h1>
        </div>
        <p className="text-slate-400 text-lg">Precision Training Platform</p>
      </div>

      {/* Difficulty Selection */}
      <div className="w-full max-w-md">
        <div className="flex items-center gap-2 mb-4">
          <Settings className="w-5 h-5 text-cyan-400" />
          <span className="text-sm text-cyan-400/70 font-mono tracking-wider">SELECT DIFFICULTY</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {difficulties.map((diff) => (
            <button
              key={diff.value}
              onClick={() => onDifficultyChange(diff.value)}
              className={`relative p-4 rounded-lg border-2 transition-all text-left ${
                difficulty === diff.value
                  ? 'border-cyan-500 bg-cyan-500/10 shadow-[0_0_20px_rgba(6,182,212,0.3)]'
                  : 'border-slate-700 bg-slate-900/50 hover:border-slate-600 hover:bg-slate-800/50'
              }`}
            >
              <div className={`font-bold ${diff.color}`}>{diff.label}</div>
              <div className="text-xs text-slate-500 mt-1">{diff.desc}</div>
              {difficulty === diff.value && (
                <div className="absolute top-2 right-2 w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
              )}
            </button>
          ))}
        </div>

        {/* Config details */}
        <div className="mt-4 p-4 bg-slate-900/50 border border-slate-700 rounded-lg">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-xs text-slate-500 mb-1">TARGET SIZE</div>
              <div className="text-lg font-mono text-cyan-400">{config.targetSize}px</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-1">DURATION</div>
              <div className="text-lg font-mono text-cyan-400">{config.targetDuration / 1000}s</div>
            </div>
            <div>
              <div className="text-xs text-slate-500 mb-1">SPAWN RATE</div>
              <div className="text-lg font-mono text-cyan-400">{config.spawnInterval / 1000}s</div>
            </div>
          </div>
        </div>
      </div>

      {/* Start Button */}
      <Button
        onClick={onStart}
        className="group relative px-12 py-6 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xl rounded-xl transition-all shadow-[0_0_30px_rgba(6,182,212,0.4)] hover:shadow-[0_0_50px_rgba(6,182,212,0.6)]"
      >
        <Play className="w-6 h-6 mr-3 group-hover:scale-110 transition-transform" />
        START TRAINING
        <ChevronRight className="w-6 h-6 ml-2 group-hover:translate-x-1 transition-transform" />
      </Button>

      {/* Instructions Dialog */}
      <Dialog open={showInstructions} onOpenChange={setShowInstructions}>
        <DialogTrigger asChild>
          <button className="flex items-center gap-2 text-slate-400 hover:text-cyan-400 transition-colors">
            <Info className="w-5 h-5" />
            <span className="text-sm">How to Play</span>
          </button>
        </DialogTrigger>
        <DialogContent className="bg-slate-900 border-cyan-500/30 max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-cyan-400">
              <Gamepad2 className="w-5 h-5" />
              How to Play
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 text-slate-300">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0">
                <Target className="w-4 h-4 text-cyan-400" />
              </div>
              <div>
                <div className="font-semibold text-white">Hit Targets</div>
                <div className="text-sm text-slate-400">Click on the targets as fast as you can before they disappear.</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                <Trophy className="w-4 h-4 text-purple-400" />
              </div>
              <div>
                <div className="font-semibold text-white">Build Combo</div>
                <div className="text-sm text-slate-400">Hit consecutive targets without missing to build your combo multiplier.</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                <Zap className="w-4 h-4 text-green-400" />
              </div>
              <div>
                <div className="font-semibold text-white">Score Points</div>
                <div className="text-sm text-slate-400">Earn points based on speed, accuracy, and combo multiplier.</div>
              </div>
            </div>
            <div className="p-3 bg-slate-800/50 rounded-lg text-sm text-slate-400">
              <strong className="text-cyan-400">Tip:</strong> Missing a shot or letting a target disappear will reset your combo!
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Import Zap for instructions
import { Zap } from 'lucide-react';
