import { useState, useCallback, useRef, useEffect } from 'react';
import type { Target, GameStats, GameState, Difficulty, GameConfig } from '@/types/game';
import { DIFFICULTY_CONFIG } from '@/types/game';

export function useGame() {
  const [gameState, setGameState] = useState<GameState>('menu');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [targets, setTargets] = useState<Target[]>([]);
  const [stats, setStats] = useState<GameStats>({
    score: 0,
    hits: 0,
    misses: 0,
    totalShots: 0,
    accuracy: 0,
    avgReactionTime: 0,
    reactionTimes: [],
  });
  const [timeLeft, setTimeLeft] = useState(60);
  const [combo, setCombo] = useState(0);
  const [maxCombo, setMaxCombo] = useState(0);

  const gameAreaRef = useRef<HTMLDivElement>(null);
  const targetIdRef = useRef(0);
  const spawnTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const gameTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const configRef = useRef<GameConfig>(DIFFICULTY_CONFIG.medium);

  useEffect(() => {
    configRef.current = DIFFICULTY_CONFIG[difficulty];
  }, [difficulty]);

  const spawnTarget = useCallback(() => {
    if (!gameAreaRef.current) return;

    const rect = gameAreaRef.current.getBoundingClientRect();
    const config = configRef.current;
    const padding = config.targetSize + 20;
    
    const x = Math.random() * (rect.width - padding * 2) + padding;
    const y = Math.random() * (rect.height - padding * 2) + padding;

    const newTarget: Target = {
      id: targetIdRef.current++,
      x,
      y,
      size: config.targetSize,
      createdAt: Date.now(),
    };

    setTargets((prev) => [...prev, newTarget]);

    // Auto-remove target after duration
    setTimeout(() => {
      setTargets((prev) => {
        const stillExists = prev.find((t) => t.id === newTarget.id && !t.hit);
        if (stillExists) {
          setCombo(0);
          setStats((s) => ({ ...s, misses: s.misses + 1 }));
          return prev.filter((t) => t.id !== newTarget.id);
        }
        return prev;
      });
    }, config.targetDuration);
  }, []);

  const startSpawning = useCallback(() => {
    if (spawnTimerRef.current) clearInterval(spawnTimerRef.current);
    spawnTimerRef.current = setInterval(spawnTarget, configRef.current.spawnInterval);
  }, [spawnTarget]);

  const stopSpawning = useCallback(() => {
    if (spawnTimerRef.current) {
      clearInterval(spawnTimerRef.current);
      spawnTimerRef.current = null;
    }
  }, []);

  const startGame = useCallback(() => {
    setGameState('playing');
    setTargets([]);
    setStats({
      score: 0,
      hits: 0,
      misses: 0,
      totalShots: 0,
      accuracy: 0,
      avgReactionTime: 0,
      reactionTimes: [],
    });
    setTimeLeft(configRef.current.totalTime);
    setCombo(0);
    setMaxCombo(0);
    targetIdRef.current = 0;

    startSpawning();

    if (gameTimerRef.current) clearInterval(gameTimerRef.current);
    gameTimerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  }, [startSpawning]);

  const endGame = useCallback(() => {
    setGameState('finished');
    stopSpawning();
    if (gameTimerRef.current) {
      clearInterval(gameTimerRef.current);
      gameTimerRef.current = null;
    }
    setTargets([]);
  }, [stopSpawning]);

  const pauseGame = useCallback(() => {
    if (gameState === 'playing') {
      setGameState('paused');
      stopSpawning();
      if (gameTimerRef.current) {
        clearInterval(gameTimerRef.current);
        gameTimerRef.current = null;
      }
    } else if (gameState === 'paused') {
      setGameState('playing');
      startSpawning();
      gameTimerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            endGame();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  }, [gameState, stopSpawning, startSpawning, endGame]);

  const handleTargetHit = useCallback((targetId: number, createdAt: number) => {
    const reactionTime = Date.now() - createdAt;
    
    setTargets((prev) => prev.filter((t) => t.id !== targetId));
    
    setCombo((prev) => {
      const newCombo = prev + 1;
      setMaxCombo((max) => Math.max(max, newCombo));
      return newCombo;
    });

    setStats((prev) => {
      const newReactionTimes = [...prev.reactionTimes, reactionTime];
      const newHits = prev.hits + 1;
      const newTotalShots = prev.totalShots + 1;
      const newAccuracy = (newHits / newTotalShots) * 100;
      const newAvgReactionTime = newReactionTimes.reduce((a, b) => a + b, 0) / newReactionTimes.length;
      
      // Score calculation: base points + combo bonus + speed bonus
      const basePoints = 100;
      const comboBonus = Math.min(combo * 10, 100);
      const speedBonus = Math.max(0, 200 - reactionTime / 10);
      const points = Math.round(basePoints + comboBonus + speedBonus);

      return {
        ...prev,
        score: prev.score + points,
        hits: newHits,
        totalShots: newTotalShots,
        accuracy: newAccuracy,
        avgReactionTime: newAvgReactionTime,
        reactionTimes: newReactionTimes,
      };
    });
  }, [combo]);

  const handleMiss = useCallback(() => {
    setCombo(0);
    setStats((prev) => {
      const newTotalShots = prev.totalShots + 1;
      const newAccuracy = (prev.hits / newTotalShots) * 100;
      return {
        ...prev,
        misses: prev.misses + 1,
        totalShots: newTotalShots,
        accuracy: newAccuracy,
      };
    });
  }, []);

  const resetGame = useCallback(() => {
    setGameState('menu');
    setTargets([]);
    setStats({
      score: 0,
      hits: 0,
      misses: 0,
      totalShots: 0,
      accuracy: 0,
      avgReactionTime: 0,
      reactionTimes: [],
    });
    setTimeLeft(configRef.current.totalTime);
    setCombo(0);
    setMaxCombo(0);
  }, []);

  useEffect(() => {
    return () => {
      if (spawnTimerRef.current) clearInterval(spawnTimerRef.current);
      if (gameTimerRef.current) clearInterval(gameTimerRef.current);
    };
  }, []);

  return {
    gameState,
    difficulty,
    setDifficulty,
    targets,
    stats,
    timeLeft,
    combo,
    maxCombo,
    gameAreaRef,
    startGame,
    endGame,
    pauseGame,
    handleTargetHit,
    handleMiss,
    resetGame,
  };
}
